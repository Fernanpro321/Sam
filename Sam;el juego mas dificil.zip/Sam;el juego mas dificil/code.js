var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":[],"propsByKey":{}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var sam= createSprite(20,190,13,13);
var banqueta1=createSprite(190,120,420,3);
banqueta1.shapeColor=("gray");
var banqueta2=createSprite(190,260,420,3);
var carro1=createSprite(100,130,10,10);
carro1.shapeColor=("black");
var carro2=createSprite(215,130,10,10);
carro2.shapeColor=("black");
var carro3=createSprite(165,250,10,10);
carro3.shapeColor=("black");
var carro4=createSprite(270,250,10,10);
carro4.shapeColor=("black");
carro1.velocityY=5;
carro2.velocityY=-4;
carro3.velocityY=6;
carro4.velocityY=-5;
var vida=0;



function draw() {
  background("aqua");
  text("vidas"+vida,300,99);
  fill("yellow");
  rect(0,120,52,140);
  fill("green");
  rect(345,120,52,140);
  if (keyDown("RIGHT_ARROW")) {
  sam.x=sam.x +2;  
  
  }
  if (keyDown("LEFT_ARROW")) {
    sam.x=sam.x -2;
  }
  if (
    sam.isTouching(carro1)|| 
    sam.isTouching(carro2)||
    sam.isTouching(carro3)||
    sam.isTouching(carro4)){
      vida=vida+1;
      sam.x=20;
      sam.y=190;
    }
  
  
  
  
  drawSprites();
  carro1.bounceOff(banqueta1);
  carro1.bounceOff(banqueta2);
  carro2.bounceOff(banqueta1);
  carro2.bounceOff(banqueta2);
  carro3.bounceOff(banqueta1);
  carro3.bounceOff(banqueta2);
  carro4.bounceOff(banqueta1);
  carro4.bounceOff(banqueta2);

}
// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
